using NUnit.Framework;
using SmokeballDevelopmentProject;

namespace SmokeBallTestProject
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            // Arrange
            var classUnderTest = new GoogleSearchSmokeBall();
            var htmlResult = @"<DIV class=""Gx5Zad fP1Qef xpd EtOod pkphOe"">< DIV class=""egMi0 kCrYT""><A href=""/url?q=https://www.smokeball.com.au/practice-area/conveyancing-software&amp";

            // Act
            var po = classUnderTest.GetSmokeBallPositions(htmlResult);

            // Assert
            Assert.AreEqual("1", po.Trim());
        }
    }
}