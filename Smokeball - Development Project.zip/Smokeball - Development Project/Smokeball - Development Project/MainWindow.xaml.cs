﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using log4net;


namespace SmokeballDevelopmentProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private GoogleSearchSmokeBall googleSmokeBall;
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public MainWindow(GoogleSearchSmokeBall googleSmokeBall)
        {
            InitializeComponent();
            this.googleSmokeBall = googleSmokeBall;
            this.txt_url.Text = "https://www.google.com.au/search?num=100&q=";
            this.txt_keyword.Text = "conveyancing+software";
            log4net.Config.XmlConfigurator.Configure();
        }

        private void btn_search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var results = googleSmokeBall.GetGoogleResults(this.txt_url.Text, this.txt_keyword.Text);

                this.txt_result.Text = googleSmokeBall.GetSmokeBallPositions(results);
            }
            catch (Exception ex)
            { 
                log.Error(ex); 

            }
        }
    }
}
