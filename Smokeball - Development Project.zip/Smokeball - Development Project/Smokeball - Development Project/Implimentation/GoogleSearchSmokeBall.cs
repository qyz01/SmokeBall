﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmokeballDevelopmentProject
{
    /// <summary>
    /// Search SmokeBall from google and get results' positions
    /// </summary>
    public class GoogleSearchSmokeBall : GoogleSearch, IGoogleSearchSmokeBall
    {
        const string SmokeBallWebsite = "www.smokeball.com.au";
        /// <summary>
        /// contructor
        /// </summary>
        public GoogleSearchSmokeBall()
        { 
        }

        /// <summary>
        /// Get search results from google by keyword
        /// </summary>
        /// <param name="url"></param>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public override string GetGoogleResults(string url, string keyword)
        {
            return base.GetGoogleResults(url, keyword);
        }

        /// <summary>
        /// Get SmokeBall from google search results position
        /// </summary>
        /// <param name="htmlResult"></param>
        /// <returns></returns>
        public string GetSmokeBallPositions(string htmlResult)
        {
            string positions = String.Empty;
            var pattern = "href=";
            int count = 0;
            int index = htmlResult.IndexOf(pattern);
            while (index != -1)
            {
                if (index > 0 && htmlResult.Substring(index, 13).Contains("url"))
                {
                    count++;
                    if ((index + 42) < htmlResult.Length && htmlResult.Substring(index, 42).Contains(SmokeBallWebsite))
                    {
                        positions += count + ", ";
                    }
                }
                index = htmlResult.IndexOf(pattern, index + pattern.Length);
            }

            return string.IsNullOrEmpty(positions) ? "0" : positions.Trim().Remove(positions.LastIndexOf(','));
        }
    }
}
