﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace SmokeballDevelopmentProject
{
    public class GoogleSearch : IGoogleSearch
    {
        /// <summary>
        /// contructor
        /// </summary>
        public GoogleSearch()
        { 
        }

        /// <summary>
        /// Get search results from google by keyword
        /// </summary>
        /// <param name="url"></param>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public virtual string GetGoogleResults(string url, string keyword)
        {
            string uri = url + keyword;
            string result = string.Empty;
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(uri);
            HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
            using (StreamReader s = new StreamReader(resp.GetResponseStream(), Encoding.ASCII))
            {
                result = s.ReadToEnd();
            }

            return result;
        }
    }
}
